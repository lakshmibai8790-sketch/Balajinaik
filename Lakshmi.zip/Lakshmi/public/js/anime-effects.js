// public/js/anime-effects.js - Interactive 3D Card Tilt, Sakura Petals & Artwork Switcher for LAKSHMI SOLUTIONS

document.addEventListener('DOMContentLoaded', () => {
  // =========================================================================
  // 1. Interactive 3D Card Tilt on Mouse Move
  // =========================================================================
  const tiltCards = document.querySelectorAll('.card-3d-interactive, .hero-3d-card');

  tiltCards.forEach(card => {
    const shine = card.querySelector('.card-3d-glare');

    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;

      // Calculate tilt angles (max +/- 15 deg)
      const rotateX = ((y - centerY) / centerY) * -12;
      const rotateY = ((x - centerX) / centerX) * 12;

      card.style.transform = `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) scale3d(1.02, 1.02, 1.02)`;

      if (shine) {
        const moveX = (x / rect.width) * 100;
        const moveY = (y / rect.height) * 100;
        shine.style.background = `radial-gradient(circle at ${moveX}% ${moveY}%, rgba(255, 255, 255, 0.45) 0%, rgba(255, 255, 255, 0.05) 60%, transparent 80%)`;
      }
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`;
      card.style.transition = 'transform 0.5s cubic-bezier(0.2, 0.8, 0.2, 1)';
      if (shine) {
        shine.style.background = 'transparent';
      }
    });

    card.addEventListener('mouseenter', () => {
      card.style.transition = 'transform 0.1s ease-out';
    });
  });

  // =========================================================================
  // 2. Artwork Switcher (Image 1 vs Image 2)
  // =========================================================================
  const artSwitchBtns = document.querySelectorAll('.art-switch-btn');
  const heroAnimeImg = document.getElementById('heroAnimeArtworkImg');
  const heroArtworkTitle = document.getElementById('heroArtworkTitle');
  const heroArtworkDesc = document.getElementById('heroArtworkDesc');

  const artworkDetails = {
    '1': {
      src: 'images/anime-art-1-landscape.jpg',
      alt: 'Moonlit Azure Waterfall & Cherry Blossoms',
      title: 'Celestial Waterfall Sanctuary',
      desc: 'Glowing full moon illuminating azure mountain waterfalls and blooming sakura trees.'
    },
    '2': {
      src: 'images/anime-art-2-landscape.jpg',
      alt: 'Twilight Violet Moon & Cascading Sakura Waters',
      title: 'Twilight Blossom Falls',
      desc: 'Ethereal pink moon casting vivid violet highlights across tiered cliffside waters.'
    }
  };

  artSwitchBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      artSwitchBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const artId = btn.dataset.art;
      const data = artworkDetails[artId];
      if (!data || !heroAnimeImg) return;

      // 3D Flip transition
      heroAnimeImg.style.opacity = '0';
      heroAnimeImg.style.transform = 'scale(0.95)';
      setTimeout(() => {
        heroAnimeImg.src = data.src;
        heroAnimeImg.alt = data.alt;
        if (heroArtworkTitle) heroArtworkTitle.textContent = data.title;
        if (heroArtworkDesc) heroArtworkDesc.textContent = data.desc;
        heroAnimeImg.style.opacity = '1';
        heroAnimeImg.style.transform = 'scale(1)';
      }, 250);
    });
  });

  // =========================================================================
  // 3. Falling Sakura Cherry Blossom Anime Particle Effect
  // =========================================================================
  initSakuraPetals();

  function initSakuraPetals() {
    let canvas = document.getElementById('sakuraCanvas');
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'sakuraCanvas';
      canvas.className = 'sakura-canvas-overlay';
      document.body.prepend(canvas);
    }

    const ctx = canvas.getContext('2d');
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    });

    let petals = [];
    const maxPetals = 38;
    let isRunning = true;

    // Petal constructor
    function Petal() {
      this.reset();
    }

    Petal.prototype.reset = function () {
      this.x = Math.random() * width;
      this.y = Math.random() * -100;
      this.size = Math.random() * 9 + 6;
      this.speedX = Math.random() * 1.5 - 0.5;
      this.speedY = Math.random() * 1.2 + 0.8;
      this.rotation = Math.random() * 360;
      this.rotSpeed = Math.random() * 2 - 1;
      this.color = Math.random() > 0.5 ? 'rgba(255, 183, 197, 0.75)' : 'rgba(255, 192, 203, 0.65)';
      this.opacity = Math.random() * 0.4 + 0.6;
    };

    Petal.prototype.update = function () {
      this.x += this.speedX + Math.sin(this.y / 30) * 0.8;
      this.y += this.speedY;
      this.rotation += this.rotSpeed;

      if (this.y > height + 20 || this.x < -20 || this.x > width + 20) {
        this.reset();
      }
    };

    Petal.prototype.draw = function () {
      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate((this.rotation * Math.PI) / 180);
      ctx.fillStyle = this.color;
      ctx.beginPath();
      // Draw organic sakura petal shape
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(this.size / 2, -this.size / 2, this.size, 0);
      ctx.quadraticCurveTo(this.size / 2, this.size / 2, 0, 0);
      ctx.fill();
      ctx.restore();
    };

    for (let i = 0; i < maxPetals; i++) {
      const p = new Petal();
      p.y = Math.random() * height; // initial distribution
      petals.push(p);
    }

    function animate() {
      if (!isRunning) return;
      ctx.clearRect(0, 0, width, height);
      for (let i = 0; i < petals.length; i++) {
        petals[i].update();
        petals[i].draw();
      }
      requestAnimationFrame(animate);
    }
    animate();

    // Petal Toggle in Topbar / Footer
    const petalToggles = document.querySelectorAll('.sakura-toggle-btn');
    petalToggles.forEach(btn => {
      btn.addEventListener('click', () => {
        isRunning = !isRunning;
        canvas.style.display = isRunning ? 'block' : 'none';
        btn.innerHTML = isRunning ? '🌸 Anime Petals: ON' : '🌸 Anime Petals: OFF';
        btn.style.opacity = isRunning ? '1' : '0.6';
        if (isRunning) animate();
      });
    });
  }

  // =========================================================================
  // 4. Interactive 3D Depth Inspector Modal
  // =========================================================================
  const open3dModalBtns = document.querySelectorAll('.open-3d-modal-btn');
  const modal3d = document.getElementById('modal3dViewer');
  const card3dDisplay = document.getElementById('modal3dCardDisplay');

  open3dModalBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      if (!modal3d) return;
      const imgSrc = btn.dataset.src || 'images/anime-art-1-landscape.jpg';
      const imgTarget = document.getElementById('modal3dImageTarget');
      if (imgTarget) imgTarget.src = imgSrc;
      modal3d.classList.add('open');
    });
  });

  if (modal3d && card3dDisplay) {
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let rotX = 0;
    let rotY = 0;

    modal3d.addEventListener('mousedown', (e) => {
      if (e.target.closest('#modal3dCardDisplay')) {
        isDragging = true;
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
      }
    });

    window.addEventListener('mouseup', () => { isDragging = false; });

    window.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;

      rotY += deltaX * 0.4;
      rotX -= deltaY * 0.4;
      // Clamp angles
      rotX = Math.max(-45, Math.min(45, rotX));
      rotY = Math.max(-60, Math.min(60, rotY));

      card3dDisplay.style.transform = `perspective(1200px) rotateX(${rotX}deg) rotateY(${rotY}deg) scale(1.05)`;
    });

    // Reset button
    document.getElementById('reset3dViewBtn')?.addEventListener('click', () => {
      rotX = 0;
      rotY = 0;
      card3dDisplay.style.transform = `perspective(1200px) rotateX(0deg) rotateY(0deg) scale(1)`;
    });
  }

  document.querySelectorAll('.close-3d-modal').forEach(btn => {
    btn.addEventListener('click', () => {
      modal3d?.classList.remove('open');
    });
  });
});

