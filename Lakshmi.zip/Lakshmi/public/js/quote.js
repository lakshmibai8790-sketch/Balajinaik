// public/js/quote.js - Multi-Step Quote Wizard for LAKSHMI SOLUTIONS

document.addEventListener('DOMContentLoaded', () => {
  const wizard = document.getElementById('quoteWizard');
  if (!wizard) return;

  let currentStep = 1;
  const totalSteps = 6;

  // State store for quotation data
  const quoteData = {
    name: '',
    business_name: '',
    email: '',
    mobile: '',
    city: '',
    website_type: 'Business Website Development',
    base_cost: 9999,
    pages_range: 'Up to 5 Pages',
    pages_cost: 0,
    features: ['WhatsApp Chat Integration', 'Contact & Lead Forms', 'Mobile Responsive Design'],
    features_cost: 0,
    budget: '₹15,000 - ₹30,000',
    timeline: 'Normal (2-3 weeks)',
    description: '',
    existing_url: '',
    reference_sites: ''
  };

  // URL query parameter pre-selection (e.g. ?package=business or ?service=ecommerce)
  const urlParams = new URLSearchParams(window.location.search);
  const pkgParam = urlParams.get('package');
  const serviceParam = urlParams.get('service');

  if (pkgParam) {
    if (pkgParam.toLowerCase().includes('starter')) {
      quoteData.website_type = 'Business Website (Starter)';
      quoteData.base_cost = 4999;
      quoteData.pages_range = 'Up to 3 Pages';
    } else if (pkgParam.toLowerCase().includes('premium')) {
      quoteData.website_type = 'Premium Business Website';
      quoteData.base_cost = 19999;
      quoteData.pages_range = 'Up to 10 Pages';
    } else if (pkgParam.toLowerCase().includes('ecommerce')) {
      quoteData.website_type = 'E-commerce Website Development';
      quoteData.base_cost = 29999;
    } else if (pkgParam.toLowerCase().includes('custom')) {
      quoteData.website_type = 'Custom Web Application';
      quoteData.base_cost = 39999;
    }
  } else if (serviceParam) {
    quoteData.website_type = serviceParam;
    if (serviceParam.toLowerCase().includes('anime')) {
      quoteData.base_cost = 34999;
      quoteData.features.push('3D Interactive Canvas & Parallax', 'Falling Sakura / Particle Anime Engine');
    }
  }

  // DOM Elements
  const prevBtn = document.getElementById('prevStepBtn');
  const nextBtn = document.getElementById('nextStepBtn');
  const submitBtn = document.getElementById('submitQuoteBtn');
  const progressBar = document.getElementById('wizardProgressBar');
  const estimateDisplay = document.getElementById('liveEstimateTotal');

  // Step 2: Website Type Card Click
  const typeCards = document.querySelectorAll('.type-card');
  typeCards.forEach(card => {
    const val = card.dataset.type;
    const cost = parseInt(card.dataset.cost || '9999', 10);
    if (val === quoteData.website_type) {
      card.classList.add('selected');
      quoteData.base_cost = cost;
    }

    card.addEventListener('click', () => {
      typeCards.forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      quoteData.website_type = val;
      quoteData.base_cost = cost;
      updateCalculatedEstimate();
    });
  });

  // Step 3: Pages Range
  const pagesSelect = document.getElementById('pagesRangeSelect');
  if (pagesSelect) {
    pagesSelect.addEventListener('change', (e) => {
      quoteData.pages_range = e.target.value;
      const extraCost = parseInt(e.target.selectedOptions[0].dataset.cost || '0', 10);
      quoteData.pages_cost = extraCost;
      updateCalculatedEstimate();
    });
  }

  // Step 3: Features Checkboxes
  const featureCheckboxes = document.querySelectorAll('.feature-checkbox');
  featureCheckboxes.forEach(chk => {
    chk.addEventListener('change', () => {
      const parent = chk.closest('.feature-choice');
      if (chk.checked) {
        parent.classList.add('checked');
      } else {
        parent.classList.remove('checked');
      }

      // Rebuild selected features & calculate
      const selected = [];
      let extraFeaturesCost = 0;
      document.querySelectorAll('.feature-checkbox:checked').forEach(c => {
        selected.push(c.value);
        extraFeaturesCost += parseInt(c.dataset.cost || '0', 10);
      });
      quoteData.features = selected;
      quoteData.features_cost = extraFeaturesCost;
      updateCalculatedEstimate();
    });
  });

  // Step 4: Budget Cards
  const budgetCards = document.querySelectorAll('.budget-card');
  budgetCards.forEach(card => {
    card.addEventListener('click', () => {
      budgetCards.forEach(b => b.classList.remove('selected'));
      card.classList.add('selected');
      quoteData.budget = card.dataset.budget;
    });
  });

  // Step 4: Timeline Radio/Select
  const timelineSelect = document.getElementById('timelineSelect');
  if (timelineSelect) {
    timelineSelect.addEventListener('change', (e) => {
      quoteData.timeline = e.target.value;
    });
  }

  // Update Dynamic Cost Estimation Display
  function updateCalculatedEstimate() {
    const total = quoteData.base_cost + quoteData.pages_cost + quoteData.features_cost;
    const formatted = '₹' + total.toLocaleString('en-IN');
    if (estimateDisplay) {
      estimateDisplay.textContent = formatted + ' Approx.';
    }
  }
  updateCalculatedEstimate();

  // Navigation Logic
  function showStep(step) {
    // Hide all steps
    document.querySelectorAll('.wizard-step-pane').forEach(p => p.classList.remove('active'));
    // Show current step
    const targetPane = document.getElementById(`stepPane${step}`);
    if (targetPane) targetPane.classList.add('active');

    // Update Step Indicators
    for (let i = 1; i <= totalSteps; i++) {
      const ind = document.getElementById(`stepInd${i}`);
      if (!ind) continue;
      ind.classList.remove('active', 'completed');
      if (i === step) {
        ind.classList.add('active');
      } else if (i < step) {
        ind.classList.add('completed');
      }
    }

    // Update Progress Bar
    const percent = ((step - 1) / (totalSteps - 1)) * 100;
    if (progressBar) progressBar.style.width = `${percent}%`;

    // Button states
    if (prevBtn) prevBtn.style.display = step === 1 ? 'none' : 'inline-flex';
    if (nextBtn) nextBtn.style.display = step === totalSteps ? 'none' : 'inline-flex';
    if (submitBtn) submitBtn.style.display = step === totalSteps ? 'inline-flex' : 'none';

    // If step 6 (Review), populate review table
    if (step === 6) {
      populateReviewSummary();
    }

    // Scroll to wizard top
    wizard.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  // Validate current step before proceeding
  function validateStep(step) {
    if (step === 1) {
      const nameInput = document.getElementById('quoteName');
      const emailInput = document.getElementById('quoteEmail');
      const mobileInput = document.getElementById('quoteMobile');

      if (!nameInput.value.trim()) {
        window.showToast('Please enter your full name.', 'error');
        nameInput.focus();
        return false;
      }
      if (!emailInput.value.trim() || !emailInput.value.includes('@')) {
        window.showToast('Please enter a valid email address.', 'error');
        emailInput.focus();
        return false;
      }
      if (!mobileInput.value.trim() || mobileInput.value.trim().length < 8) {
        window.showToast('Please enter a valid mobile / WhatsApp number.', 'error');
        mobileInput.focus();
        return false;
      }

      quoteData.name = nameInput.value.trim();
      quoteData.business_name = document.getElementById('quoteBusiness').value.trim();
      quoteData.email = emailInput.value.trim();
      quoteData.mobile = mobileInput.value.trim();
      quoteData.city = document.getElementById('quoteCity').value.trim();
    }

    if (step === 5) {
      quoteData.description = document.getElementById('quoteDescription').value.trim();
      quoteData.existing_url = document.getElementById('quoteExistingUrl').value.trim();
      quoteData.reference_sites = document.getElementById('quoteRefSites').value.trim();
    }

    return true;
  }

  // Populate Review Table (Step 6)
  function populateReviewSummary() {
    const summaryContainer = document.getElementById('reviewSummaryContent');
    if (!summaryContainer) return;

    const totalEstimate = quoteData.base_cost + quoteData.pages_cost + quoteData.features_cost;

    summaryContainer.innerHTML = `
      <table class="review-summary-table">
        <tr>
          <td class="label-col">Client Name</td>
          <td class="val-col"><strong>${quoteData.name}</strong> (${quoteData.business_name || 'Individual'})</td>
        </tr>
        <tr>
          <td class="label-col">Contact Info</td>
          <td class="val-col">${quoteData.email} &bull; ${quoteData.mobile} ${quoteData.city ? `(${quoteData.city})` : ''}</td>
        </tr>
        <tr>
          <td class="label-col">Website Type</td>
          <td class="val-col"><span class="badge-navy" style="padding: 4px 12px; border-radius: 99px; font-weight: 700;">${quoteData.website_type}</span></td>
        </tr>
        <tr>
          <td class="label-col">Page Scope</td>
          <td class="val-col">${quoteData.pages_range}</td>
        </tr>
        <tr>
          <td class="label-col">Selected Features</td>
          <td class="val-col">
            <div style="display: flex; flex-wrap: wrap; gap: 6px;">
              ${quoteData.features.map(f => `<span class="portfolio-tag" style="background:#FFF9EB; color:#B45309; border-color:#FDE68A;">${f}</span>`).join('')}
            </div>
          </td>
        </tr>
        <tr>
          <td class="label-col">Budget & Timeline</td>
          <td class="val-col"><strong>${quoteData.budget}</strong> &bull; Timeline: ${quoteData.timeline}</td>
        </tr>
        <tr>
          <td class="label-col">Calculated Ballpark</td>
          <td class="val-col" style="font-size: 1.15rem; font-weight: 800; color: #F59E0B;">₹${totalEstimate.toLocaleString('en-IN')} (Estimated Base)</td>
        </tr>
        ${quoteData.description ? `
        <tr>
          <td class="label-col">Project Notes</td>
          <td class="val-col" style="font-style: italic;">"${quoteData.description}"</td>
        </tr>` : ''}
      </table>
    `;
  }

  // Next Button Click
  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      if (!validateStep(currentStep)) return;
      if (currentStep < totalSteps) {
        currentStep++;
        showStep(currentStep);
      }
    });
  }

  // Prev Button Click
  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      if (currentStep > 1) {
        currentStep--;
        showStep(currentStep);
      }
    });
  }

  // Submit Quote Button
  if (submitBtn) {
    submitBtn.addEventListener('click', async () => {
      submitBtn.disabled = true;
      submitBtn.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation: spin 1s linear infinite;">
          <circle cx="12" cy="12" r="10" stroke-opacity="0.25"/><path d="M12 2a10 10 0 0110 10"/>
        </svg> Submitting Your Quote...
      `;

      try {
        const response = await fetch('/api/quote', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(quoteData)
        });

        const resData = await response.json();

        if (response.ok && resData.success) {
          showSuccessConfirmation(resData.refNumber || 'LSQ-NEW', quoteData);
        } else {
          throw new Error(resData.error || 'Server error occurred');
        }
      } catch (err) {
        console.warn('API error or server offline. Using client fallback:', err);
        // Fallback for direct file-viewing or offline demonstration
        const offlineRef = 'LSQ-' + Math.floor(1000 + Math.random() * 9000);
        const stored = JSON.parse(localStorage.getItem('lakshmi_offline_quotes') || '[]');
        stored.push({ ...quoteData, id: offlineRef, created_at: new Date().toISOString() });
        localStorage.setItem('lakshmi_offline_quotes', JSON.stringify(stored));

        showSuccessConfirmation(offlineRef, quoteData);
      }
    });
  }

  // Display celebratory confirmation state
  function showSuccessConfirmation(refNumber, data) {
    const wizardBody = document.querySelector('.wizard-body');
    const wizardHeader = document.querySelector('.wizard-header');
    if (wizardHeader) wizardHeader.style.display = 'none';

    wizardBody.innerHTML = `
      <div style="text-align: center; padding: 40px 20px;">
        <div style="width: 80px; height: 80px; background: #ECFDF5; color: #10B981; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 24px; box-shadow: 0 10px 25px rgba(16, 185, 129, 0.2);">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg>
        </div>
        <span class="badge-amber" style="margin-bottom: 12px;">Quotation Request Confirmed</span>
        <h2 style="font-size: 2.2rem; font-weight: 800; color: #101D35; margin-bottom: 12px;">Thank You, ${data.name}!</h2>
        <p style="font-size: 1.1rem; color: #5F6E84; max-width: 600px; margin: 0 auto 24px; line-height: 1.6;">
          Your custom website quotation request has been successfully recorded under reference ID:
        </p>
        <div style="display: inline-block; background: #101D35; color: #F59E0B; padding: 12px 28px; border-radius: 12px; font-size: 1.4rem; font-weight: 800; letter-spacing: 0.05em; margin-bottom: 30px; box-shadow: 0 8px 20px rgba(16, 29, 53, 0.2);">
          ${refNumber}
        </div>
        <p style="font-size: 0.95rem; color: #5F6E84; max-width: 580px; margin: 0 auto 36px;">
          Our Senior Solutions Architect is reviewing your technical specifications for <strong>${data.website_type}</strong>. We will share a tailored proposal and schedule a quick consultation call within 2-4 business hours.
        </p>
        <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 16px;">
          <a href="https://wa.me/919876543210?text=Hi%20Lakshmi%20Solutions,%20I%20have%20submitted%20quote%20request%20${refNumber}.%20Can%20we%20discuss?" target="_blank" class="btn btn-primary">
            <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.301-.15-1.78-.878-2.056-.98-.276-.102-.477-.15-.678.15-.2.302-.78 1.03-.956 1.23-.175.202-.351.226-.652.076-.3-.15-1.267-.467-2.414-1.488-.893-.796-1.496-1.78-1.672-2.08-.175-.302-.019-.465.132-.615.136-.135.301-.35.452-.525.15-.175.2-.299.3-.5.1-.2.05-.375-.025-.525-.075-.15-.677-1.632-.928-2.235-.245-.588-.494-.508-.678-.517l-.578-.01c-.2 0-.525.075-.8.375-.275.3-1.05 1.026-1.05 2.502s1.075 2.898 1.225 3.1c.15.2 2.115 3.23 5.124 4.53.716.31 1.275.495 1.71.634.72.23 1.374.197 1.892.12.578-.087 1.78-.727 2.03-1.43.25-.702.25-1.304.175-1.43-.075-.125-.276-.2-.577-.35z"/></svg>
            Connect on WhatsApp Now
          </a>
          <a href="/" class="btn btn-secondary">Back to Homepage</a>
        </div>
      </div>
    `;

    window.showToast('Quotation request submitted successfully!', 'success');
  }
});

