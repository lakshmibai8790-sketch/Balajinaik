// public/js/contact.js - Contact Form Interactions for LAKSHMI SOLUTIONS

document.addEventListener('DOMContentLoaded', () => {
  const contactForm = document.getElementById('agencyContactForm');
  if (!contactForm) return;

  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const submitBtn = contactForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;

    // Gather inputs
    const name = document.getElementById('contactName')?.value.trim();
    const business_name = document.getElementById('contactBusiness')?.value.trim();
    const email = document.getElementById('contactEmail')?.value.trim();
    const mobile = document.getElementById('contactMobile')?.value.trim();
    const website_type = document.getElementById('contactWebsiteType')?.value;
    const budget = document.getElementById('contactBudget')?.value;
    const description = document.getElementById('contactDescription')?.value.trim();

    // Basic Validation
    if (!name) {
      window.showToast('Please enter your full name.', 'error');
      document.getElementById('contactName').focus();
      return;
    }
    if (!email || !email.includes('@')) {
      window.showToast('Please enter a valid email address.', 'error');
      document.getElementById('contactEmail').focus();
      return;
    }
    if (!mobile || mobile.length < 8) {
      window.showToast('Please enter a valid phone / mobile number.', 'error');
      document.getElementById('contactMobile').focus();
      return;
    }

    const payload = {
      name,
      business_name,
      email,
      mobile,
      website_type,
      budget,
      description
    };

    submitBtn.disabled = true;
    submitBtn.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation: spin 1s linear infinite;">
        <circle cx="12" cy="12" r="10" stroke-opacity="0.25"/><path d="M12 2a10 10 0 0110 10"/>
      </svg> Sending Enquiry...
    `;

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const resData = await response.json();

      if (response.ok && resData.success) {
        showSuccessModal(resData.refNumber || 'LS-C001', payload);
        contactForm.reset();
      } else {
        throw new Error(resData.error || 'Server error occurred');
      }
    } catch (err) {
      console.warn('API error or server offline. Using client fallback:', err);
      const offlineRef = 'LS-C' + Math.floor(1000 + Math.random() * 9000);
      const stored = JSON.parse(localStorage.getItem('lakshmi_offline_contacts') || '[]');
      stored.push({ ...payload, id: offlineRef, created_at: new Date().toISOString() });
      localStorage.setItem('lakshmi_offline_contacts', JSON.stringify(stored));

      showSuccessModal(offlineRef, payload);
      contactForm.reset();
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  });

  function showSuccessModal(refId, data) {
    const modalBackdrop = document.getElementById('contactSuccessModal');
    if (!modalBackdrop) {
      window.showToast(`Thank you, ${data.name}! Your enquiry has been received (Ref: ${refId}).`, 'success');
      return;
    }

    const modalRefSpan = document.getElementById('modalRefNumber');
    const modalNameSpan = document.getElementById('modalClientName');
    if (modalRefSpan) modalRefSpan.textContent = refId;
    if (modalNameSpan) modalNameSpan.textContent = data.name;

    modalBackdrop.classList.add('open');
  }

  // Close modal
  const closeModalBtns = document.querySelectorAll('.close-modal-trigger');
  closeModalBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.modal-backdrop').forEach(m => m.classList.remove('open'));
    });
  });
});

