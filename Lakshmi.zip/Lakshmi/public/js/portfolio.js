// public/js/portfolio.js - Portfolio gallery & Live Interactive Demo Modal for LAKSHMI SOLUTIONS

document.addEventListener('DOMContentLoaded', () => {
  // 1. Category Filter Logic
  const filterBtns = document.querySelectorAll('.filter-btn');
  const portfolioCards = document.querySelectorAll('.portfolio-item-col');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filterValue = btn.dataset.filter;

      portfolioCards.forEach(card => {
        const category = card.dataset.category;
        if (filterValue === 'all' || category === filterValue) {
          card.style.display = 'block';
          card.style.animation = 'fadeIn 0.3s ease';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // 2. Demo Modal Data & Switcher
  const demoModal = document.getElementById('portfolioDemoModal');
  const demoModalTitle = document.getElementById('demoModalTitle');
  const demoModalCategory = document.getElementById('demoModalCategory');
  const demoFrame = document.getElementById('demoFrameContent');
  const demoQuoteBtn = document.getElementById('demoQuoteCta');

  // Interactive Live Demo Simulations
  const demoProjects = {
    corporate: {
      title: 'Apex Global Advisory & Consulting',
      category: 'Corporate Business Website Demo',
      serviceQuery: 'Business Website Development',
      content: `
        <div style="font-family: inherit; color: #1E293B;">
          <div style="background: #0F172A; color: #FFF; padding: 12px 24px; display: flex; justify-content: space-between; align-items: center; border-radius: 8px;">
            <div style="font-weight: 800; font-size: 1.1rem; color: #38BDF8;">APEX GLOBAL <span style="font-weight: 400; color: #94A3B8;">| Advisory</span></div>
            <div style="display: flex; gap: 16px; font-size: 0.85rem;">
              <span>Home</span><span>Practice Areas</span><span>Insights</span><span>Careers</span>
            </div>
            <button style="background: #38BDF8; color: #0F172A; border: none; padding: 6px 14px; border-radius: 4px; font-weight: 700; font-size: 0.8rem; cursor: pointer;">Schedule Briefing</button>
          </div>
          <div style="padding: 40px 20px; text-align: center; background: linear-gradient(180deg, #F8FAFC 0%, #FFFFFF 100%); margin-top: 10px; border-radius: 8px;">
            <span style="background: #E0F2FE; color: #0369A1; font-size: 0.75rem; font-weight: 700; padding: 4px 12px; border-radius: 99px;">STRATEGIC EXCELLENCE</span>
            <h2 style="font-size: 1.8rem; font-weight: 800; color: #0F172A; margin: 14px 0;">Transforming Enterprise Vision into Market Leadership</h2>
            <p style="color: #64748B; font-size: 0.95rem; max-width: 600px; margin: 0 auto 20px;">We advise Fortune 500s and emerging scale-ups across cross-border M&A, digital transformation, and risk governance.</p>
            <div style="display: flex; justify-content: center; gap: 12px;">
              <button style="background: #0F172A; color: #FFF; padding: 10px 20px; border-radius: 6px; font-weight: 700; border: none;">Explore Advisory Practices</button>
              <button style="background: #F1F5F9; color: #334155; padding: 10px 20px; border-radius: 6px; font-weight: 600; border: 1px solid #CBD5E1;">Download 2026 Outlook</button>
            </div>
          </div>
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-top: 20px;">
            <div style="padding: 16px; border: 1px solid #E2E8F0; border-radius: 8px; background: #FFF;">
              <div style="color: #0284C7; font-weight: 800; font-size: 1.2rem; margin-bottom: 4px;">450+</div>
              <div style="font-size: 0.85rem; font-weight: 700;">Global Transactions</div>
              <div style="font-size: 0.75rem; color: #64748B; margin-top: 4px;">Over $12B cumulative enterprise deal advisory completed.</div>
            </div>
            <div style="padding: 16px; border: 1px solid #E2E8F0; border-radius: 8px; background: #FFF;">
              <div style="color: #0284C7; font-weight: 800; font-size: 1.2rem; margin-bottom: 4px;">98.4%</div>
              <div style="font-size: 0.85rem; font-weight: 700;">Client Retention</div>
              <div style="font-size: 0.75rem; color: #64748B; margin-top: 4px;">Long-standing counsel with premier institutional boards.</div>
            </div>
            <div style="padding: 16px; border: 1px solid #E2E8F0; border-radius: 8px; background: #FFF;">
              <div style="color: #0284C7; font-weight: 800; font-size: 1.2rem; margin-bottom: 4px;">24 Offices</div>
              <div style="font-size: 0.85rem; font-weight: 700;">Worldwide Network</div>
              <div style="font-size: 0.75rem; color: #64748B; margin-top: 4px;">Direct presence in London, Singapore, Mumbai, and NY.</div>
            </div>
          </div>
        </div>
      `
    },
    ecommerce: {
      title: 'Velvet Aura Premium Apparel',
      category: 'E-commerce Shopping Website Demo',
      serviceQuery: 'E-commerce Website Development',
      content: `
        <div style="font-family: inherit; color: #2D3748;">
          <div style="background: #1A202C; color: #FFF; padding: 12px 20px; display: flex; justify-content: space-between; align-items: center; border-radius: 8px;">
            <div style="font-weight: 900; letter-spacing: 0.1em; font-size: 1.2rem; color: #ECC94B;">VELVET AURA</div>
            <div style="display: flex; gap: 16px; font-size: 0.85rem;">
              <span>New Arrivals</span><span>Dresses</span><span>Festive</span><span>Sale</span>
            </div>
            <div style="display: flex; align-items: center; gap: 12px; font-size: 0.85rem;">
              <span>🔍 Search</span>
              <span style="background: #D69E2E; color: #1A202C; padding: 4px 10px; border-radius: 99px; font-weight: 800;">Cart (3)</span>
            </div>
          </div>
          <div style="padding: 24px; background: #F7FAFC; margin-top: 10px; border-radius: 8px; display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 20px; align-items: center;">
            <div>
              <span style="color: #B7791F; font-size: 0.8rem; font-weight: 700; text-transform: uppercase;">Summer Luxury Collection</span>
              <h3 style="font-size: 1.6rem; font-weight: 800; margin: 8px 0; color: #1A202C;">Handcrafted Mulberry Silk Edit</h3>
              <p style="font-size: 0.85rem; color: #718096; margin-bottom: 16px;">Pure organic silk hand-spun with subtle gold Zari detailing. Designed for modern celebrations.</p>
              <div style="font-size: 1.3rem; font-weight: 800; color: #1A202C; margin-bottom: 16px;">₹6,499 <span style="font-size: 0.9rem; color: #A0AEC0; text-decoration: line-through;">₹8,999</span> <span style="font-size: 0.8rem; color: #38A169;">(28% OFF)</span></div>
              <button onclick="window.showToast('Item added to shopping bag demo!', 'success')" style="background: #1A202C; color: #ECC94B; border: none; padding: 10px 22px; border-radius: 6px; font-weight: 700; cursor: pointer;">Add to Bag & Checkout</button>
            </div>
            <div style="background: linear-gradient(135deg, #ECC94B 0%, #D69E2E 100%); border-radius: 8px; height: 160px; display: flex; align-items: center; justify-content: center; color: #1A202C; font-weight: 800; font-size: 1.2rem; text-align: center; padding: 20px;">
              [Velvet Aura Haute Couture Mockup]
            </div>
          </div>
        </div>
      `
    },
    logistics: {
      title: 'SwiftTrack Express Cargo & Freight',
      category: 'Logistics and Courier Website Demo',
      serviceQuery: 'Logistics Website Development',
      content: `
        <div style="font-family: inherit; color: #1E293B;">
          <div style="background: #0284C7; color: #FFF; padding: 12px 20px; display: flex; justify-content: space-between; align-items: center; border-radius: 8px;">
            <div style="font-weight: 900; font-size: 1.15rem; display: flex; align-items: center; gap: 8px;">🚚 SWIFTTRACK EXPRESS</div>
            <div style="display: flex; gap: 14px; font-size: 0.85rem;">
              <span>Domestic Express</span><span>Air Freight</span><span>B2B Cargo</span><span>Branch Locator</span>
            </div>
          </div>
          <div style="background: #F0F9FF; border: 1px solid #BAE6FD; padding: 24px; border-radius: 8px; margin-top: 14px;">
            <h3 style="font-size: 1.3rem; font-weight: 800; color: #0369A1; margin-bottom: 6px;">Live Consignment / Parcel Tracking</h3>
            <p style="font-size: 0.85rem; color: #64748B; margin-bottom: 16px;">Enter your AWB tracking or Docket Number to inspect real-time transit telemetry.</p>
            <div style="display: flex; gap: 10px;">
              <input type="text" id="demoTrackingInput" value="ST-IND-994821" style="flex: 1; padding: 10px 14px; border: 1px solid #94A3B8; border-radius: 6px; font-family: monospace; font-size: 0.95rem;" placeholder="e.g. ST-IND-994821" />
              <button onclick="document.getElementById('demoTrackingStatus').style.display='block'" style="background: #0284C7; color: #FFF; border: none; padding: 10px 20px; border-radius: 6px; font-weight: 700; cursor: pointer;">Track Parcel</button>
            </div>
            <div id="demoTrackingStatus" style="margin-top: 18px; padding: 14px; background: #FFF; border-radius: 6px; border: 1px solid #E2E8F0;">
              <div style="display: flex; justify-content: space-between; font-size: 0.85rem; margin-bottom: 8px;">
                <span style="font-weight: 700; color: #0284C7;">AWB: ST-IND-994821</span>
                <span style="background: #DCFCE7; color: #166534; font-weight: 700; padding: 2px 8px; border-radius: 4px;">Out For Delivery</span>
              </div>
              <div style="font-size: 0.8rem; color: #475569;">
                📍 Current Station: <strong>Chennai Central Hub (Anna Salai)</strong> &bull; Estimated Delivery: <strong>Today, 4:30 PM</strong>
              </div>
            </div>
          </div>
        </div>
      `
    },
    education: {
      title: 'Oakridge International Academy',
      category: 'School and College Website Demo',
      serviceQuery: 'Education Website Development',
      content: `
        <div style="font-family: inherit; color: #1E293B;">
          <div style="background: #1E3A8A; color: #FFF; padding: 12px 20px; display: flex; justify-content: space-between; align-items: center; border-radius: 8px;">
            <div style="font-weight: 800; font-size: 1.1rem;">🎓 OAKRIDGE INTERNATIONAL</div>
            <div style="display: flex; gap: 14px; font-size: 0.85rem;">
              <span>About</span><span>Academics</span><span>Admissions 2026-27</span><span>Campus Life</span><span>Parent Portal</span>
            </div>
            <button style="background: #F59E0B; color: #1E3A8A; border: none; padding: 6px 14px; border-radius: 4px; font-weight: 800; font-size: 0.8rem; cursor: pointer;">Apply Online</button>
          </div>
          <div style="padding: 24px; background: #F8FAFC; border-radius: 8px; margin-top: 12px; display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div>
              <span style="color: #2563EB; font-size: 0.75rem; font-weight: 700; text-transform: uppercase;">Admissions Open &bull; CBSE & Cambridge Curriculum</span>
              <h3 style="font-size: 1.5rem; font-weight: 800; color: #1E3A8A; margin: 10px 0;">Nurturing Global Thinkers, Innovators & Leaders</h3>
              <p style="font-size: 0.85rem; color: #64748B; line-height: 1.6; margin-bottom: 16px;">State-of-the-art robotic labs, olympic-size swimming complex, smart digital classrooms and 100% Ivy League & IIT placement records.</p>
              <button onclick="window.showToast('Online Admission Prospectus opened!', 'success')" style="background: #1E3A8A; color: #FFF; border: none; padding: 8px 18px; border-radius: 6px; font-weight: 700; font-size: 0.85rem; cursor: pointer;">Download Prospectus (PDF)</button>
            </div>
            <div style="background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 8px; padding: 18px;">
              <h4 style="font-size: 0.95rem; font-weight: 700; color: #1E3A8A; margin-bottom: 10px;">📢 Latest Institutional Notices</h4>
              <ul style="font-size: 0.8rem; color: #3B82F6; line-height: 1.7;">
                <li>&bull; <a href="#" style="text-decoration: underline;">Grade XI Merit Scholarship Exam Dates Announced</a></li>
                <li>&bull; <a href="#" style="text-decoration: underline;">Annual Cultural Festival 'AURA 2026' Schedule</a></li>
                <li>&bull; <a href="#" style="text-decoration: underline;">Inter-School Robotics Championship Winners List</a></li>
              </ul>
            </div>
          </div>
        </div>
      `
    },
    restaurant: {
      title: 'Saffron & Spice Fine Indian Bistro',
      category: 'Restaurant Website Demo',
      serviceQuery: 'Restaurant Website Development',
      content: `
        <div style="font-family: inherit; color: #2D3748;">
          <div style="background: #4A154B; color: #FFF; padding: 12px 20px; display: flex; justify-content: space-between; align-items: center; border-radius: 8px;">
            <div style="font-weight: 900; letter-spacing: 0.08em; font-size: 1.15rem; color: #F6AD55;">🌶️ SAFFRON & SPICE</div>
            <div style="display: flex; gap: 16px; font-size: 0.85rem;">
              <span>Our Story</span><span>A La Carte</span><span>Tasting Menu</span><span>Private Dining</span>
            </div>
            <button onclick="window.showToast('Table Reservation dialog opened!', 'success')" style="background: #F6AD55; color: #4A154B; border: none; padding: 6px 14px; border-radius: 4px; font-weight: 800; font-size: 0.8rem; cursor: pointer;">Reserve a Table</button>
          </div>
          <div style="padding: 24px; background: #FFF5F5; border-radius: 8px; margin-top: 12px;">
            <div style="text-align: center; max-width: 500px; margin: 0 auto 20px;">
              <span style="color: #9B2C2C; font-size: 0.75rem; font-weight: 800; letter-spacing: 0.1em; text-transform: uppercase;">Royal Awadhi & Chettinad Gastronomy</span>
              <h3 style="font-size: 1.6rem; font-weight: 800; color: #4A154B; margin-top: 6px;">Authentic Flavours Redefined with Modern Flair</h3>
            </div>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px;">
              <div style="background: #FFF; padding: 14px; border-radius: 6px; border: 1px solid #FED7D7;">
                <div style="font-weight: 700; font-size: 0.9rem; color: #742A2A;">Dum Pukht Gosht Biryani</div>
                <div style="font-size: 0.75rem; color: #718096; margin: 4px 0;">Slow-cooked aged basmati with aromatic pot spices.</div>
                <div style="font-weight: 800; color: #C53030; font-size: 0.95rem;">₹595</div>
              </div>
              <div style="background: #FFF; padding: 14px; border-radius: 6px; border: 1px solid #FED7D7;">
                <div style="font-weight: 700; font-size: 0.9rem; color: #742A2A;">Paneer Kadhai Lababdar</div>
                <div style="font-size: 0.75rem; color: #718096; margin: 4px 0;">Charcoal roasted cottage cheese in smoked cashew gravy.</div>
                <div style="font-weight: 800; color: #C53030; font-size: 0.95rem;">₹445</div>
              </div>
              <div style="background: #FFF; padding: 14px; border-radius: 6px; border: 1px solid #FED7D7;">
                <div style="font-weight: 700; font-size: 0.9rem; color: #742A2A;">Saffron Rasmalai Souffle</div>
                <div style="font-size: 0.75rem; color: #718096; margin: 4px 0;">Infused with Kashmiri saffron, pistachios & silver vark.</div>
                <div style="font-weight: 800; color: #C53030; font-size: 0.95rem;">₹295</div>
              </div>
            </div>
          </div>
        </div>
      `
    },
    portfolio: {
      title: 'Dr. Priya Raman – Strategic Management Consultant',
      category: 'Personal Portfolio Website Demo',
      serviceQuery: 'Portfolio Website Development',
      content: `
        <div style="font-family: inherit; color: #1E293B;">
          <div style="background: #111827; color: #FFF; padding: 12px 20px; display: flex; justify-content: space-between; align-items: center; border-radius: 8px;">
            <div style="font-weight: 800; font-size: 1.1rem; letter-spacing: 0.05em; color: #10B981;">DR. PRIYA RAMAN, Ph.D.</div>
            <div style="display: flex; gap: 14px; font-size: 0.85rem;">
              <span>Bio</span><span>Keynotes</span><span>Publications</span><span>Advisory</span><span>Press</span>
            </div>
            <button style="background: #10B981; color: #111827; border: none; padding: 6px 14px; border-radius: 4px; font-weight: 800; font-size: 0.8rem; cursor: pointer;">Book Speaking Session</button>
          </div>
          <div style="padding: 30px 20px; background: #F9FAFB; border-radius: 8px; margin-top: 12px; display: flex; gap: 24px; align-items: center;">
            <div style="width: 110px; height: 110px; border-radius: 50%; background: #111827; color: #10B981; font-size: 2rem; font-weight: 800; display: flex; align-items: center; justify-content: center; flex-shrink: 0; border: 3px solid #10B981;">
              PR
            </div>
            <div>
              <span style="background: #D1FAE5; color: #065F46; font-size: 0.75rem; font-weight: 700; padding: 3px 10px; border-radius: 99px;">GLOBAL KEYNOTE SPEAKER & BOARD ADVISOR</span>
              <h3 style="font-size: 1.4rem; font-weight: 800; color: #111827; margin: 8px 0;">Author of 'The Agile Boardroom' & Former McKinsey Partner</h3>
              <p style="font-size: 0.85rem; color: #6B7280; line-height: 1.5; margin-bottom: 12px;">Delivered 200+ keynote addresses across WEF Davos, TEDx, and Harvard Business School on resilient organizational design.</p>
              <div style="display: flex; gap: 12px;">
                <span style="font-size: 0.75rem; font-weight: 700; color: #374151;">Featured in: Financial Times &bull; Forbes &bull; Harvard Business Review</span>
              </div>
            </div>
          </div>
        </div>
      `
    },
    anime: {
      title: 'Hikari Anime & Manga Production Studio',
      category: 'Anime, Manga & Creative Studio Website Demo',
      serviceQuery: 'Anime, Gaming & Creative Media Web Development',
      content: `
        <div style="font-family: inherit; color: #FFF; background: #0B1324; border-radius: 8px; overflow: hidden; padding: 16px;">
          <!-- Anime Studio Navigation -->
          <div style="background: rgba(16, 29, 53, 0.95); padding: 12px 20px; display: flex; justify-content: space-between; align-items: center; border-radius: 6px; border: 1px solid rgba(255, 183, 197, 0.25);">
            <div style="font-weight: 900; letter-spacing: 0.08em; font-size: 1.15rem; color: #FFB7C5; display: flex; align-items: center; gap: 8px;">
              <span>🌸 HIKARI STUDIOS</span>
              <span style="font-size: 0.7rem; color: #38BDF8; font-weight: 600; background: rgba(56, 189, 248, 0.15); padding: 2px 8px; border-radius: 99px;">OFFICIAL PORTAL</span>
            </div>
            <div style="display: flex; gap: 14px; font-size: 0.85rem; color: rgba(255,255,255,0.8);">
              <span>Series</span><span>Characters</span><span>Manga Reader</span><span>Merchandise</span>
            </div>
            <button onclick="window.showToast('Episode 1 Teaser Trailer launching in 4K!', 'success')" style="background: linear-gradient(135deg, #FFB7C5 0%, #F59E0B 100%); color: #0B1324; border: none; padding: 6px 14px; border-radius: 4px; font-weight: 800; font-size: 0.8rem; cursor: pointer;">Watch Trailer</button>
          </div>

          <!-- Featured Artwork Showcase Grid -->
          <div style="display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 16px; margin-top: 14px;">
            <div style="position: relative; border-radius: 8px; overflow: hidden; height: 260px; box-shadow: 0 10px 25px rgba(0,0,0,0.6);">
              <img src="images/anime-art-1-landscape.jpg" alt="Celestial Waterfall" style="width: 100%; height: 100%; object-fit: cover;">
              <div style="position: absolute; bottom: 0; left: 0; right: 0; padding: 16px; background: linear-gradient(180deg, transparent 0%, rgba(11, 19, 36, 0.95) 100%);">
                <span style="background: #38BDF8; color: #0B1324; font-size: 0.7rem; font-weight: 800; padding: 2px 8px; border-radius: 4px;">KEY VISUAL 01</span>
                <h4 style="font-size: 1.15rem; font-weight: 800; color: #FFF; margin: 4px 0;">Celestial Waterfall: Tale of the Moonlit Blade</h4>
                <p style="font-size: 0.75rem; color: rgba(255,255,255,0.8);">Original Animation Series launching worldwide Autumn 2026.</p>
              </div>
            </div>

            <div style="position: relative; border-radius: 8px; overflow: hidden; height: 260px; box-shadow: 0 10px 25px rgba(0,0,0,0.6);">
              <img src="images/anime-art-2-landscape.jpg" alt="Twilight Blossom Falls" style="width: 100%; height: 100%; object-fit: cover;">
              <div style="position: absolute; bottom: 0; left: 0; right: 0; padding: 16px; background: linear-gradient(180deg, transparent 0%, rgba(11, 19, 36, 0.95) 100%);">
                <span style="background: #FFB7C5; color: #0B1324; font-size: 0.7rem; font-weight: 800; padding: 2px 8px; border-radius: 4px;">KEY VISUAL 02</span>
                <h4 style="font-size: 1.15rem; font-weight: 800; color: #FFF; margin: 4px 0;">Twilight Sakura Falls</h4>
                <p style="font-size: 0.75rem; color: rgba(255,255,255,0.8);">Manga Volume IV Collector's Edition Artwork.</p>
              </div>
            </div>
          </div>

          <!-- Studio Feature Widgets -->
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-top: 14px;">
            <div style="background: rgba(16, 29, 53, 0.8); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 12px;">
              <div style="font-size: 0.75rem; color: #FFB7C5; font-weight: 700;">🌸 Cherry Blossom Physics</div>
              <div style="font-size: 0.85rem; font-weight: 600; margin-top: 2px;">Real-time falling sakura canvas engine</div>
            </div>
            <div style="background: rgba(16, 29, 53, 0.8); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 12px;">
              <div style="font-size: 0.75rem; color: #38BDF8; font-weight: 700;">🎮 3D Artwork Viewer</div>
              <div style="font-size: 0.85rem; font-weight: 600; margin-top: 2px;">Interactive mouse tilt perspective</div>
            </div>
            <div style="background: rgba(16, 29, 53, 0.8); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 12px;">
              <div style="font-size: 0.75rem; color: #F59E0B; font-weight: 700;">🛍️ Merch Pre-Order</div>
              <div style="font-size: 0.85rem; font-weight: 600; margin-top: 2px;">Direct Razorpay & Stripe integration</div>
            </div>
          </div>
        </div>
      `
    }
  };

  // Open Live Demo Modal
  const demoButtons = document.querySelectorAll('.view-demo-btn');
  demoButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const demoKey = btn.dataset.project;
      const project = demoProjects[demoKey];
      if (!project || !demoModal) return;

      demoModalTitle.textContent = project.title;
      demoModalCategory.textContent = project.category;
      demoFrame.innerHTML = project.content;
      if (demoQuoteBtn) {
        demoQuoteBtn.href = `/quote.html?service=${encodeURIComponent(project.serviceQuery)}`;
        demoQuoteBtn.textContent = `Get a Quote for this Style →`;
      }

      demoModal.classList.add('open');
    });
  });

  // Device Switcher
  const deviceBtns = document.querySelectorAll('.device-btn');
  deviceBtns.forEach(dBtn => {
    dBtn.addEventListener('click', () => {
      deviceBtns.forEach(b => b.classList.remove('active'));
      dBtn.classList.add('active');

      const device = dBtn.dataset.device;
      if (device === 'mobile') {
        demoFrame.style.maxWidth = '375px';
      } else if (device === 'tablet') {
        demoFrame.style.maxWidth = '768px';
      } else {
        demoFrame.style.maxWidth = '100%';
      }
    });
  });

  // Close Modal
  document.querySelectorAll('.close-demo-modal').forEach(btn => {
    btn.addEventListener('click', () => {
      demoModal?.classList.remove('open');
    });
  });
});

