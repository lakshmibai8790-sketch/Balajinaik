// test-server.js - Comprehensive end-to-end verification of all routes and APIs
const http = require('node:http');

// Spawn server process or test directly
const { spawn } = require('node:child_process');
const serverProc = spawn('node', ['server.js'], { stdio: 'inherit' });

function request(method, path, body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const opts = {
      hostname: 'localhost',
      port: 3000,
      path,
      method,
      headers: { ...headers }
    };
    if (body) {
      opts.headers['Content-Type'] = 'application/json';
      opts.headers['Content-Length'] = Buffer.byteLength(body);
    }
    const req = http.request(opts, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function runTests() {
  console.log('Waiting 1.5s for server to bind...');
  await new Promise(r => setTimeout(r, 1500));

  let passed = 0;
  let failed = 0;

  async function assertRoute(name, fn) {
    try {
      await fn();
      console.log(`✅ [PASS] ${name}`);
      passed++;
    } catch (e) {
      console.error(`❌ [FAIL] ${name}:`, e.message);
      failed++;
    }
  }

  // 1. Static pages
  const pages = ['/', '/about', '/services', '/portfolio', '/pricing', '/contact', '/quote', '/admin'];
  for (const p of pages) {
    await assertRoute(`Page ${p}`, async () => {
      const res = await request('GET', p);
      if (res.status !== 200) throw new Error(`Expected 200, got ${res.status}`);
      if (!res.body.includes('LAKSHMI SOLUTIONS')) throw new Error('Missing brand header in response');
    });
  }

  // 2. Submit Contact Form
  let contactId = null;
  await assertRoute('POST /api/contact', async () => {
    const payload = JSON.stringify({
      name: 'Sunil Narayanan',
      business_name: 'Sunil Retail Enterprises',
      email: 'sunil@sunilretail.com',
      mobile: '+91 98401 22334',
      website_type: 'E-commerce Website Development',
      budget: '₹25,000 - ₹50,000',
      description: 'Looking to build an online grocery store with delivery tracking'
    });
    const res = await request('POST', '/api/contact', payload);
    if (res.status !== 201) throw new Error(`Expected 201, got ${res.status}: ${res.body}`);
    const json = JSON.parse(res.body);
    if (!json.success || !json.refNumber) throw new Error('Invalid JSON response');
    contactId = json.id;
  });

  // 3. Submit Quote Form
  let quoteId = null;
  await assertRoute('POST /api/quote', async () => {
    const payload = JSON.stringify({
      name: 'Meenakshi Sundaram',
      business_name: 'Meenakshi Dental Hospital',
      email: 'dr.meenakshi@hospital.org',
      mobile: '+91 99620 44556',
      website_type: 'Business Website Development',
      pages_range: '6 to 10 Pages',
      features: ['WhatsApp Chat Integration', 'Online Appointment Booking', 'Mobile Responsive'],
      budget: '₹15,000 - ₹30,000',
      timeline: 'Normal (2-3 weeks)',
      description: 'Clinic portal with doctor schedule and booking'
    });
    const res = await request('POST', '/api/quote', payload);
    if (res.status !== 201) throw new Error(`Expected 201, got ${res.status}: ${res.body}`);
    const json = JSON.parse(res.body);
    if (!json.success || !json.refNumber.startsWith('LSQ-')) throw new Error('Invalid quote ref format');
    quoteId = json.id;
  });

  // 4. Admin Login
  let adminToken = null;
  await assertRoute('POST /api/admin/login', async () => {
    const res = await request('POST', '/api/admin/login', JSON.stringify({
      email: 'admin@lakshmisolutions.com',
      password: 'admin@lakshmi2026'
    }));
    if (res.status !== 200) throw new Error(`Expected 200, got ${res.status}: ${res.body}`);
    const json = JSON.parse(res.body);
    if (!json.token) throw new Error('Missing token in login response');
    adminToken = json.token;
  });

  // 5. Admin Enquiries Fetch
  await assertRoute('GET /api/admin/enquiries', async () => {
    const res = await request('GET', '/api/admin/enquiries', null, {
      Authorization: `Bearer ${adminToken}`
    });
    if (res.status !== 200) throw new Error(`Expected 200, got ${res.status}`);
    const json = JSON.parse(res.body);
    if (!Array.isArray(json.enquiries) || json.enquiries.length < 5) {
      throw new Error(`Expected at least 5 enquiries, got ${json.enquiries?.length}`);
    }
  });

  // 6. Admin Update Status
  await assertRoute(`PATCH /api/admin/enquiries/${contactId}`, async () => {
    const res = await request('PATCH', `/api/admin/enquiries/${contactId}`, JSON.stringify({
      status: 'Contacted',
      admin_notes: 'Spoke with Sunil on phone. Meeting set for Monday.'
    }), {
      Authorization: `Bearer ${adminToken}`
    });
    if (res.status !== 200) throw new Error(`Expected 200, got ${res.status}`);
    const json = JSON.parse(res.body);
    if (json.enquiry.status !== 'Contacted') throw new Error('Status not updated');
  });

  // 7. Admin Stats
  await assertRoute('GET /api/admin/stats', async () => {
    const res = await request('GET', '/api/admin/stats', null, {
      Authorization: `Bearer ${adminToken}`
    });
    if (res.status !== 200) throw new Error(`Expected 200, got ${res.status}`);
    const json = JSON.parse(res.body);
    if (!json.stats || json.stats.total < 5) throw new Error('Invalid stats object');
  });

  // 8. Admin CSV Export
  await assertRoute('GET /api/admin/export', async () => {
    const res = await request('GET', '/api/admin/export', null, {
      Authorization: `Bearer ${adminToken}`
    });
    if (res.status !== 200) throw new Error(`Expected 200, got ${res.status}`);
    if (!res.body.includes('ID,Type,Name,Business Name')) throw new Error('Invalid CSV header');
  });

  console.log('========================================================');
  console.log(`Test Execution Finished: ${passed} passed, ${failed} failed`);
  console.log('========================================================');

  serverProc.kill();
  process.exit(failed > 0 ? 1 : 0);
}

runTests().catch(err => {
  console.error('Test runner fatal error:', err);
  serverProc.kill();
  process.exit(1);
});

