# LAKSHMI SOLUTIONS – Professional Website Development Agency

> **Tagline:** *"Your Vision, Our Digital Creation."*  
> **Headline:** *"We Build Websites That Build Your Business."*

A modern, premium, high-performance, and fully responsive website for **Lakshmi Solutions**, a professional digital web design and development agency.

---

## 🌟 Key Highlights & Features

1. **Brand Identity & Premium Design System**
   - **Primary Color:** Deep Navy Blue (`#101D35`)
   - **Secondary Accent:** Vibrant Amber / Gold Orange (`#F59E0B`)
   - **Backgrounds:** Pure White (`#FFFFFF`) & Soft Tech Neutral (`#F5F7FA`)
   - **Typography:** High-readability modern sans-serif (`Plus Jakarta Sans`)
   - **Custom Logo:** Unique geometric brackets `{ }` and digital diamond/node icon paired with sleek brand typography.

2. **Complete 7 Core Customer Pages + Admin Dashboard**
   - **Home (`index.html`):** Hero section with interactive 3D browser mockup, animated metric chips, client trust strip, services overview, portfolio highlights, "Why Choose Us" cards, interactive cost estimator, client reviews, and final CTA.
   - **3D & Anime Visual Studio Integration:** Interactive 3D Card Stage with mouse perspective tilt, dynamic light sheen glare, falling sakura cherry blossom canvas particle physics engine (with toggle), and both user celestial landscape artworks (`anime-art-1.jpg` & `anime-art-2.jpg`).
   - **About Us (`about.html`):** Company background, mission, vision, core values, 6-step agile development process, creative 3D media division spotlight, and agency comparison table.
   - **Services (`services.html`):** Comprehensive breakdown of all 9 core services, including Business, E-Commerce, Logistics, Education, Restaurant, Portfolio, Custom Apps, Maintenance, and **Anime, Gaming & Creative Media Web Development** (with 3D canvas integration).
   - **Portfolio (`portfolio.html`):** Filterable showcase of 7 realistic industry demo projects, including **Hikari Studios (Anime & Manga Digital Media Studio)**, with an **Interactive Live Demo Modal** featuring a device switcher (Desktop, Tablet, Mobile) and interactive simulations.
   - **Pricing (`pricing.html`):** Fixed-price transparent package cards (Starter, Business, Premium, E-Commerce, Custom Apps, and **Anime & 3D Interactive Media Package** from ₹34,999), comparison table, and FAQs.
   - **Contact Us (`contact.html`):** Full contact form with fields for Customer Name, Business Name, Email, Mobile, Website Type (including Anime Studio), Budget, Description, WhatsApp button, Google Maps, and 3D preview card.
   - **Get a Quote (`quote.html`):** 6-step interactive quotation wizard with a real-time price estimation engine, feature selector (including 3D models and sakura particles), budget bands, review screen, and celebratory confirmation.
   - **Admin Dashboard (`admin.html`):** Secure password-protected administrative portal to view real-time leads (including anime studio inquiries), inspect client specifications, update statuses, write internal notes, and export CSV.
   - **Master Prompt (`PROMPT.md`):** Complete, fully structured prompt file included in the zip file for immediate reproduction or inspection.

3. **Backend Architecture & Database**
   - **Native Zero-Dependency Server:** Built using Node.js standard library (`node:http`, `node:fs`, `node:crypto`).
   - **Persistent SQLite Database:** Powered by Node.js 22's built-in `node:sqlite` (`database.sqlite`).
   - **Pre-Seeded Data:** Automatically pre-populated with realistic client demo inquiries so the dashboard is immediately populated.
   - **Graceful Client Fallback:** If opened directly as static HTML files via `file://`, forms seamlessly fall back to browser `localStorage`.

---

## 🚀 Quick Start Guide

### Option 1: Double-Click Launcher (Windows)
Simply double-click the included `start.bat` file in this directory.

### Option 2: Command Line
```bash
npm start
# OR
node server.js
```

Then open your browser at:
- **Public Website:** [http://localhost:3000](http://localhost:3000)
- **Admin Dashboard:** [http://localhost:3000/admin](http://localhost:3000/admin)

---

## 🔐 Default Admin Credentials

- **Email:** `admin@lakshmisolutions.com`
- **Password:** `admin@lakshmi2026`

*(These credentials are also conveniently displayed on the admin login screen for easy testing and evaluation).*

---

## 📁 Directory Structure

```text
Lakshmi/
├── database.sqlite       # SQLite database (auto-created on first run)
├── package.json          # Project metadata and start script
├── server.js             # Native HTTP server, REST APIs & SQLite integration
├── start.bat             # 1-click Windows launcher
├── README.md             # Project documentation
└── public/
    ├── css/
    │   └── style.css     # Unified master stylesheet (Brand system, cards, tables, modals)
    ├── js/
    │   ├── main.js       # Sticky header, mobile nav drawer, toast notifications
    │   ├── quote.js      # 6-step wizard, dynamic pricing calculator, API submission
    │   ├── contact.js    # Contact form handling, validation, API submission
    │   ├── portfolio.js  # Category filters, device switcher, live demo simulations
    │   └── admin.js      # Auth, inquiries retrieval, status update, notes, CSV export
    ├── index.html        # 1. Homepage
    ├── about.html        # 2. About Us
    ├── services.html     # 3. Services (All 8 services)
    ├── portfolio.html    # 4. Portfolio (6 demo projects + interactive modal)
    ├── pricing.html      # 5. Pricing (All packages + comparison)
    ├── contact.html      # 6. Contact Us (Form, WhatsApp, Google Maps)
    ├── quote.html        # 7. Get a Quote (6-step interactive wizard)
    └── admin.html        # 8. Admin Dashboard
```

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/contact` | Submits contact enquiry and saves to SQLite |
| `POST` | `/api/quote` | Submits multi-step quotation request |
| `POST` | `/api/admin/login` | Authenticates administrator credentials |
| `GET` | `/api/admin/enquiries` | Fetches filtered & searched customer enquiries |
| `PATCH`| `/api/admin/enquiries/:id` | Updates status (`New` $\rightarrow$ `Completed`) & notes |
| `DELETE`| `/api/admin/enquiries/:id` | Deletes an enquiry |
| `GET` | `/api/admin/stats` | Returns real-time metrics and pipeline estimates |
| `GET` | `/api/admin/export` | Generates and downloads `enquiries.csv` |

---

© 2026 **LAKSHMI SOLUTIONS**. All rights reserved.

