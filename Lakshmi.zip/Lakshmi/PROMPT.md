# MASTER PROMPT: LAKSHMI SOLUTIONS – PREMIUM AGENCY WEBSITE WITH 3D & ANIME VISUAL EFFECTS

> Use this exact prompt specification to reproduce or extend the complete **Lakshmi Solutions** website, 3D visual effects, anime styling, persistent SQLite backend, and secure admin dashboard.

---

```markdown
# PROJECT: LAKSHMI SOLUTIONS – DIGITAL WEBSITE DEVELOPMENT AGENCY

Act as a senior UI/UX designer, creative frontend developer, backend engineer, and website branding expert.

Build a complete, modern, premium, and fully responsive website for a digital website design and development agency named **LAKSHMI SOLUTIONS**.

---

## 1. COMPANY & BRAND IDENTITY

- **Company Name:** LAKSHMI SOLUTIONS
- **Industry:** Website Design & Development
- **Business Type:** Digital Web Development Agency
- **Tagline:** "Your Vision, Our Digital Creation."
- **Main Headline:** "We Build Websites That Build Your Business."
- **Brand Colour Palette:**
  - Primary: Deep Navy Blue (`#101D35`)
  - Secondary: Vibrant Amber / Gold Orange (`#F59E0B`)
  - Background: Pure White (`#FFFFFF`)
  - Light Background: Soft Tech Neutral (`#F5F7FA`)
  - Text: Dark Grey (`#263247`)
  - Accents: Sakura Blossom Pink (`#FFB7C5`), Celestial Azure (`#38BDF8`), Emerald Green (`#10B981`)
- **Typography:** Modern clean sans-serif (*Plus Jakarta Sans* / system-ui fallback).
- **Logo:** Unique geometric brackets `{ }` and radiant growth diamond paired with bold navy and amber typography.

---

## 2. 3D VISUAL EFFECTS & ANIME ATMOSPHERE

1. **User Artwork Integration:**
   - Integrate the two provided vertical celestial anime landscape artworks (cascading mountain waterfalls, glowing full moon, pink blooming cherry blossoms) across all pages.
   - High-resolution versions (`anime-art-1.jpg`, `anime-art-2.jpg`) and 16:9 landscape editions (`anime-art-1-landscape.jpg`, `anime-art-2-landscape.jpg`).
2. **Interactive 3D Card Tilt Engine:**
   - Mouse movement 3D perspective tilt (`perspective(1000px) rotateX(...) rotateY(...) scale3d(1.02, 1.02, 1.02)`).
   - Dynamic cursor-following light glare and sheen reflection.
   - 3D layer pop-outs (`translateZ(50px)` for titles and badges).
3. **Falling Sakura (Cherry Blossom) Particle Physics Engine:**
   - HTML5 `<canvas id="sakuraCanvas">` particle system simulating falling, swaying, and tumbling pink sakura petals.
   - Interactive toggle control in the header/topbar: `🌸 Anime Petals: ON / OFF`.
4. **Interactive 3D Depth Inspector Modal:**
   - Full-screen modal allowing visitors to click and drag in 3D space to inspect artwork angles with real-time yaw/pitch rotation.

---

## 3. WEBSITE PAGES (ALL 8 COMPLETE PAGES)

1. **Home (`index.html`):**
   - Hero section with interactive 3D Artwork Card Stage and Artwork 1 vs Artwork 2 switcher.
   - Floating performance badges (99/100 PageSpeed, 3D Parallax).
   - Trust strip covering all 10 target commercial sectors.
   - Dedicated **"Anime & 3D Interactive Media Showcase"** with side-by-side neon-bordered cards.
   - Services overview grid, featured portfolio previews, "Why Choose Us" cards.
   - Interactive quick website cost calculator, client testimonials, and final CTA banner.

2. **About Us (`about.html`):**
   - Company background and official introduction.
   - Mission, Vision, and 4 Core Values.
   - 6-Step Agile Development Process (Discovery -> Wireframe -> Code -> QA -> Launch -> Support).
   - Specialized **"Creative Arts, 3D & Anime Web Division"** spotlight with 3D tilt preview.
   - Side-by-side agency comparison matrix table.

3. **Services (`services.html`):**
   - Cards with custom SVG icons, descriptions, feature checklists, pricing tags, and direct enquiry buttons:
     A. Business Website Development (from ₹4,999)
     B. E-commerce Shopping Stores (from ₹29,999)
     C. Logistics & Courier Tracking Websites (from ₹19,999)
     D. Education & College Portals (from ₹19,999)
     E. Restaurant & Online Menu Portals (from ₹9,999)
     F. Personal Portfolio Websites (from ₹4,999)
     G. Custom Web Applications & SaaS (from ₹39,999)
     H. Website Maintenance & AMC (from ₹1,999/mo)
     I. **Anime, Gaming & Creative Media Web Development** (from ₹34,999) with 3D canvas integration.

4. **Portfolio (`portfolio.html`):**
   - Interactive category filter buttons: All, Anime & Creative, Corporate, E-Commerce, Logistics, Education, Restaurant, Portfolio.
   - 7 Demo Projects including:
     1. Apex Global Advisory (Corporate Business)
     2. Velvet Aura Couture (E-Commerce)
     3. SwiftTrack Express (Logistics)
     4. Oakridge International (Education)
     5. Saffron & Spice Bistro (Restaurant)
     6. Dr. Priya Raman (Personal Portfolio)
     7. **Hikari Studios (Anime & Manga Digital Media Studio)**
   - Interactive Live Demo Modal with Desktop / Tablet / Mobile simulator switcher.

5. **Pricing (`pricing.html`):**
   - Fixed-price transparent package cards:
     - Starter Package: ₹4,999
     - Business Package: ₹9,999 (Most Popular Value)
     - Premium Package: ₹19,999
     - E-Commerce Package: ₹29,999 onwards
     - Custom Web Application: Starting at ₹39,999
     - **Anime & 3D Interactive Media Package: Starting at ₹34,999**
   - Side-by-side package comparison matrix, domain/hosting transparency disclaimer, and FAQs.

6. **Contact Us (`contact.html`):**
   - Multi-field contact form (Name, Business, Email, Mobile, Website Type dropdown including Anime Studio option, Budget, Description).
   - 3D anime interactive card preview in contact info column.
   - One-click direct WhatsApp button (`wa.me`), phone numbers, email addresses, office location.
   - Interactive Google Maps embed preview.
   - Database submission via REST API with confirmation reference code modal (`LS-C001`).

7. **Get a Quote (`quote.html`):**
   - 6-step interactive wizard with progress bar and step indicators:
     - Step 1: Customer details & company name.
     - Step 2: Website category selector (includes Anime & 3D Creative Studio).
     - Step 3: Required pages slider & feature checkboxes (includes 3D canvas and sakura physics).
     - Step 4: Budget bands & delivery timeline selector.
     - Step 5: Project description, existing URL & references.
     - Step 6: Live review table with calculated price estimate & submission.
   - Celebratory confirmation screen with Reference ID (`LSQ-0005`) and WhatsApp follow-up link.

8. **Admin Dashboard (`admin.html`):**
   - Password-protected administrative gateway:
     - Default Email: `admin@lakshmisolutions.com`
     - Default Password: `admin@lakshmi2026`
   - Real-time statistics cards (Total Enquiries, New Leads, Quotes, Contacts, Pipeline Value).
   - Search by client name, business, email, phone, or website type.
   - Filter by status (*New, Contacted, Proposal Sent, In Progress, Completed, Closed*) and type.
   - Detail drawer to inspect full specifications, selected features, budget, and update status and internal notes.
   - One-click **Export to CSV** button (`/api/admin/export`).

---

## 4. BACKEND & PERSISTENT DATABASE ARCHITECTURE

- **Runtime:** Native Node.js HTTP server (`server.js`). Zero external `npm` packages required.
- **Database:** Persistent SQLite database via built-in `node:sqlite` (`database.sqlite`).
- **REST API Endpoints:**
  - `POST /api/contact` - Saves contact form leads.
  - `POST /api/quote` - Saves multi-step quotation requests.
  - `POST /api/admin/login` - Authenticates administrator with session token.
  - `GET /api/admin/enquiries` - Queries filtered and searched leads.
  - `PATCH /api/admin/enquiries/:id` - Updates lead status and admin follow-up notes.
  - `DELETE /api/admin/enquiries/:id` - Deletes/archives an inquiry.
  - `GET /api/admin/stats` - Computes pipeline metrics.
  - `GET /api/admin/export` - Streams downloadable CSV file.
- **Pre-Seeded Data:** Automatically pre-populated with realistic demo leads (logistics, education, restaurant, and anime studio) for immediate dashboard demonstration.
- **Client Offline Fallback:** Graceful `localStorage` fallback if files are browsed via `file://`.

---

## 5. LAUNCHING THE APPLICATION

- **Windows 1-Click:** Double-click `start.bat`.
- **Terminal:** Run `node server.js` or `npm start`.
- **Public URL:** `http://localhost:3000`
- **Admin URL:** `http://localhost:3000/admin`
```

