// server.js - High performance native HTTP server with built-in SQLite for LAKSHMI SOLUTIONS
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const DB_FILE = path.join(__dirname, 'database.sqlite');

// Initialize SQLite database
const db = new DatabaseSync(DB_FILE);

// Setup database tables
db.exec(`
  CREATE TABLE IF NOT EXISTS enquiries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL, -- 'contact' or 'quote'
    name TEXT NOT NULL,
    business_name TEXT DEFAULT '',
    email TEXT NOT NULL,
    mobile TEXT NOT NULL,
    website_type TEXT DEFAULT '',
    budget TEXT DEFAULT '',
    timeline TEXT DEFAULT '',
    pages_range TEXT DEFAULT '',
    features TEXT DEFAULT '[]',
    description TEXT DEFAULT '',
    existing_url TEXT DEFAULT '',
    reference_sites TEXT DEFAULT '',
    status TEXT DEFAULT 'New', -- 'New', 'Contacted', 'Proposal Sent', 'In Progress', 'Completed', 'Closed'
    admin_notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS admin_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
`);

// Setup default admin credentials: admin@lakshmisolutions.com / admin@lakshmi2026
const hashPassword = (pwd) => crypto.createHash('sha256').update(pwd).digest('hex');
const defaultAdminEmail = 'admin@lakshmisolutions.com';
const defaultAdminHash = hashPassword('admin@lakshmi2026');

const existingAdmin = db.prepare('SELECT id FROM admin_users WHERE email = ?').get(defaultAdminEmail);
if (!existingAdmin) {
  const insertAdmin = db.prepare('INSERT INTO admin_users (email, password_hash, name, created_at) VALUES (?, ?, ?, ?)');
  insertAdmin.run(defaultAdminEmail, defaultAdminHash, 'Lakshmi Admin', new Date().toISOString());
  console.log('Default admin created: admin@lakshmisolutions.com / admin@lakshmi2026');
}

// Seed initial realistic enquiries if table is empty
const countEnquiries = db.prepare('SELECT COUNT(*) as count FROM enquiries').get();
if (countEnquiries.count === 0) {
  const seedStmt = db.prepare(`
    INSERT INTO enquiries (
      type, name, business_name, email, mobile, website_type, budget, timeline, pages_range, features, description, status, admin_notes, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const now = new Date();
  const d1 = new Date(now - 1000 * 60 * 45).toISOString();
  const d2 = new Date(now - 1000 * 60 * 60 * 3).toISOString();
  const d3 = new Date(now - 1000 * 60 * 60 * 24).toISOString();
  const d4 = new Date(now - 1000 * 60 * 60 * 48).toISOString();

  seedStmt.run(
    'quote',
    'Rajesh Verma',
    'Verma Logistics & Cargo',
    'rajesh.verma@vermalogistics.in',
    '+91 98450 12345',
    'Logistics Website Development',
    '₹30,000 - ₹50,000',
    'Normal (2-3 weeks)',
    '6-10 pages',
    JSON.stringify(['Live Parcel / Shipment Tracking', 'WhatsApp Chat Integration', 'Mobile Responsive', 'Admin Dashboard']),
    'Need a modern fleet and parcel tracking website for our south India operations with shipment status lookup.',
    'New',
    'High priority logistics enquiry. Client requested WhatsApp callback.',
    d1,
    d1
  );

  seedStmt.run(
    'contact',
    'Ananya Sundaram',
    'Saffron Bistro & Sweets',
    'ananya@saffronbistro.com',
    '+91 98841 98765',
    'Restaurant Website Development',
    '₹10,000 - ₹25,000',
    'Urgent (Within 1 week)',
    '1-5 pages',
    JSON.stringify(['Online Menu', 'Table Booking Form', 'WhatsApp Ordering']),
    'Opening our second branch in T. Nagar next month. Need a beautiful restaurant website with digital menu and table enquiry.',
    'Contacted',
    'Called client on 20th. Sent restaurant demo links. Awaiting menu PDF.',
    d2,
    d2
  );

  seedStmt.run(
    'quote',
    'Dr. K. Senthil Kumar',
    'Sri Lakshmi Academy of Sciences',
    'principal@srilakshmiacademy.edu.in',
    '+91 94440 55667',
    'Education Website Development',
    '₹50,000 - ₹1,00,000',
    'Flexible (1 month+)',
    '11-20 pages',
    JSON.stringify(['Student/Parent Portal', 'Admissions Enquiry', 'Notice Board', 'Payment Gateway Integration']),
    'Complete portal upgrade for CBSE affiliated school with admissions form and online fee payment setup.',
    'Proposal Sent',
    'Detailed technical proposal & quotation of ₹65,000 sent via email.',
    d3,
    d3
  );

  seedStmt.run(
    'contact',
    'Vikramaditya Roy',
    'Roy Fashion Couture',
    'vikram@roycouture.in',
    '+91 97112 34567',
    'E-commerce Website Development',
    '₹25,000 - ₹50,000',
    '2-3 weeks',
    '6-10 pages',
    JSON.stringify(['Product Catalog', 'Shopping Cart', 'Razorpay Gateway', 'Order Management']),
    'Looking for a stylish ethnic wear e-commerce store with UPI payments and Instagram feed integration.',
    'In Progress',
    'Advance payment received. UI wireframes shared with client.',
    d4,
    d4
  );

  seedStmt.run(
    'quote',
    'Kenji Takahashi',
    'Hikari Animation & Manga Studios',
    'kenji@hikaristudios.jp',
    '+91 98840 77889',
    'Anime, Gaming & Creative Media Web Development',
    '₹50,000+',
    'Normal (2-3 weeks)',
    '11-20 pages',
    JSON.stringify(['3D Interactive Art Viewer', 'Falling Sakura Animation', 'Manga Lore Encyclopedia', 'Merchandise Pre-order']),
    'Need a high-octane 3D anime studio website for our upcoming celestial waterfall series with video teasers and character lore.',
    'New',
    'Anime studio client. Requested 3D mouse parallax and celestial night artwork integration.',
    now.toISOString(),
    now.toISOString()
  );

  console.log('Seeded realistic demo enquiries including Anime & Creative Studio projects.');
}

// In-memory token store for admin sessions
const activeTokens = new Map();

// Helper: Parse JSON request body
function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
      if (body.length > 2 * 1024 * 1024) { // 2MB limit
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      try {
        if (!body.trim()) {
          resolve({});
        } else {
          resolve(JSON.parse(body));
        }
      } catch (err) {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

// Helper: Send JSON response
function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
}

// Helper: Verify Admin Token
function verifyAuth(req) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return false;
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  return activeTokens.has(token);
}

// MIME types map
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.ttf': 'font/ttf'
};

// Route mapping for clean URLs
const ROUTE_MAP = {
  '/': '/index.html',
  '/home': '/index.html',
  '/about': '/about.html',
  '/about-us': '/about.html',
  '/services': '/services.html',
  '/portfolio': '/portfolio.html',
  '/pricing': '/pricing.html',
  '/contact': '/contact.html',
  '/contact-us': '/contact.html',
  '/quote': '/quote.html',
  '/get-a-quote': '/quote.html',
  '/admin': '/admin.html',
  '/admin-dashboard': '/admin.html'
};

const server = http.createServer(async (req, res) => {
  // CORS Preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    return res.end();
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // -------------------------------------------------------------
  // API ENDPOINTS
  // -------------------------------------------------------------

  // POST /api/contact - Submit contact form enquiry
  if (req.method === 'POST' && pathname === '/api/contact') {
    try {
      const data = await parseJsonBody(req);
      const { name, business_name, email, mobile, website_type, budget, description } = data;

      if (!name || !email || !mobile) {
        return sendJson(res, 400, { success: false, error: 'Name, email, and mobile are required.' });
      }

      const now = new Date().toISOString();
      const stmt = db.prepare(`
        INSERT INTO enquiries (
          type, name, business_name, email, mobile, website_type, budget, description, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'New', ?, ?)
      `);

      stmt.run(
        'contact',
        name.trim(),
        (business_name || '').trim(),
        email.trim(),
        mobile.trim(),
        (website_type || 'General Website').trim(),
        (budget || 'Flexible').trim(),
        (description || '').trim(),
        now,
        now
      );

      // Fetch the last inserted ID
      const last = db.prepare('SELECT last_insert_rowid() as id').get();
      return sendJson(res, 201, {
        success: true,
        id: last.id,
        refNumber: `LS-C${String(last.id).padStart(4, '0')}`,
        message: 'Thank you! Your message has been received. Our web specialist will get in touch with you within 2-4 business hours.'
      });
    } catch (err) {
      console.error('Error saving contact enquiry:', err);
      return sendJson(res, 500, { success: false, error: 'Internal server error while saving enquiry.' });
    }
  }

  // POST /api/quote - Submit multi-step quote request
  if (req.method === 'POST' && pathname === '/api/quote') {
    try {
      const data = await parseJsonBody(req);
      const {
        name,
        business_name,
        email,
        mobile,
        website_type,
        pages_range,
        features,
        budget,
        timeline,
        description,
        existing_url,
        reference_sites
      } = data;

      if (!name || !email || !mobile) {
        return sendJson(res, 400, { success: false, error: 'Name, email, and mobile are required.' });
      }

      const now = new Date().toISOString();
      const featuresJson = Array.isArray(features) ? JSON.stringify(features) : (typeof features === 'string' ? features : '[]');

      const stmt = db.prepare(`
        INSERT INTO enquiries (
          type, name, business_name, email, mobile, website_type, budget, timeline, pages_range, features, description, existing_url, reference_sites, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'New', ?, ?)
      `);

      stmt.run(
        'quote',
        name.trim(),
        (business_name || '').trim(),
        email.trim(),
        mobile.trim(),
        (website_type || 'Business Website Development').trim(),
        (budget || 'Not specified').trim(),
        (timeline || 'Flexible').trim(),
        (pages_range || '1-5 pages').trim(),
        featuresJson,
        (description || '').trim(),
        (existing_url || '').trim(),
        (reference_sites || '').trim(),
        now,
        now
      );

      const last = db.prepare('SELECT last_insert_rowid() as id').get();
      return sendJson(res, 201, {
        success: true,
        id: last.id,
        refNumber: `LSQ-${String(last.id).padStart(4, '0')}`,
        message: 'Your custom website quotation request has been submitted successfully! A senior project architect has been assigned to your requirement.'
      });
    } catch (err) {
      console.error('Error saving quote enquiry:', err);
      return sendJson(res, 500, { success: false, error: 'Internal server error while saving quote.' });
    }
  }

  // POST /api/admin/login - Authenticate admin
  if (req.method === 'POST' && pathname === '/api/admin/login') {
    try {
      const { email, password } = await parseJsonBody(req);
      if (!email || !password) {
        return sendJson(res, 400, { success: false, error: 'Email and password are required.' });
      }

      const pHash = hashPassword(password);
      const user = db.prepare('SELECT id, email, name FROM admin_users WHERE email = ? AND password_hash = ?').get(email.trim(), pHash);

      if (!user) {
        return sendJson(res, 401, { success: false, error: 'Invalid admin credentials. Please check your email and password.' });
      }

      // Generate secure session token
      const token = 'ls_adm_' + crypto.randomBytes(32).toString('hex');
      activeTokens.set(token, {
        userId: user.id,
        email: user.email,
        name: user.name,
        expiresAt: Date.now() + 24 * 60 * 60 * 1000 // 24 hours
      });

      return sendJson(res, 200, {
        success: true,
        token,
        user: { id: user.id, email: user.email, name: user.name }
      });
    } catch (err) {
      return sendJson(res, 500, { success: false, error: 'Login failed due to a server error.' });
    }
  }

  // GET /api/admin/enquiries - Retrieve enquiries with search & filter
  if (req.method === 'GET' && pathname === '/api/admin/enquiries') {
    if (!verifyAuth(req)) {
      return sendJson(res, 401, { success: false, error: 'Unauthorized access. Please login as admin.' });
    }

    try {
      const type = parsedUrl.searchParams.get('type') || '';
      const status = parsedUrl.searchParams.get('status') || '';
      const search = (parsedUrl.searchParams.get('search') || '').trim().toLowerCase();

      let query = 'SELECT * FROM enquiries WHERE 1=1';
      const params = [];

      if (type && type !== 'all') {
        query += ' AND type = ?';
        params.push(type);
      }

      if (status && status !== 'all') {
        query += ' AND status = ?';
        params.push(status);
      }

      if (search) {
        query += ' AND (LOWER(name) LIKE ? OR LOWER(business_name) LIKE ? OR LOWER(email) LIKE ? OR mobile LIKE ? OR LOWER(website_type) LIKE ?)';
        const wild = `%${search}%`;
        params.push(wild, wild, wild, wild, wild);
      }

      query += ' ORDER BY id DESC';

      const enquiries = db.prepare(query).all(...params);
      return sendJson(res, 200, { success: true, count: enquiries.length, enquiries });
    } catch (err) {
      console.error('Error fetching enquiries:', err);
      return sendJson(res, 500, { success: false, error: 'Failed to retrieve enquiries.' });
    }
  }

  // PATCH /api/admin/enquiries/:id - Update status and admin notes
  if (req.method === 'PATCH' && pathname.startsWith('/api/admin/enquiries/')) {
    if (!verifyAuth(req)) {
      return sendJson(res, 401, { success: false, error: 'Unauthorized.' });
    }

    try {
      const idStr = pathname.replace('/api/admin/enquiries/', '').trim();
      const id = parseInt(idStr, 10);
      if (isNaN(id)) return sendJson(res, 400, { success: false, error: 'Invalid ID.' });

      const data = await parseJsonBody(req);
      const { status, admin_notes } = data;
      const now = new Date().toISOString();

      let updateQuery = 'UPDATE enquiries SET updated_at = ?';
      const params = [now];

      if (status !== undefined) {
        updateQuery += ', status = ?';
        params.push(status);
      }

      if (admin_notes !== undefined) {
        updateQuery += ', admin_notes = ?';
        params.push(admin_notes);
      }

      updateQuery += ' WHERE id = ?';
      params.push(id);

      db.prepare(updateQuery).run(...params);
      const updated = db.prepare('SELECT * FROM enquiries WHERE id = ?').get(id);

      return sendJson(res, 200, { success: true, enquiry: updated });
    } catch (err) {
      return sendJson(res, 500, { success: false, error: 'Failed to update enquiry.' });
    }
  }

  // DELETE /api/admin/enquiries/:id - Delete an enquiry
  if (req.method === 'DELETE' && pathname.startsWith('/api/admin/enquiries/')) {
    if (!verifyAuth(req)) {
      return sendJson(res, 401, { success: false, error: 'Unauthorized.' });
    }

    try {
      const idStr = pathname.replace('/api/admin/enquiries/', '').trim();
      const id = parseInt(idStr, 10);
      if (isNaN(id)) return sendJson(res, 400, { success: false, error: 'Invalid ID.' });

      db.prepare('DELETE FROM enquiries WHERE id = ?').run(id);
      return sendJson(res, 200, { success: true, message: `Enquiry #${id} deleted successfully.` });
    } catch (err) {
      return sendJson(res, 500, { success: false, error: 'Failed to delete enquiry.' });
    }
  }

  // GET /api/admin/stats - High level statistics
  if (req.method === 'GET' && pathname === '/api/admin/stats') {
    if (!verifyAuth(req)) {
      return sendJson(res, 401, { success: false, error: 'Unauthorized.' });
    }

    try {
      const total = db.prepare('SELECT COUNT(*) as count FROM enquiries').get().count;
      const contactCount = db.prepare("SELECT COUNT(*) as count FROM enquiries WHERE type = 'contact'").get().count;
      const quoteCount = db.prepare("SELECT COUNT(*) as count FROM enquiries WHERE type = 'quote'").get().count;
      const newCount = db.prepare("SELECT COUNT(*) as count FROM enquiries WHERE status = 'New'").get().count;
      const inProgressCount = db.prepare("SELECT COUNT(*) as count FROM enquiries WHERE status = 'In Progress'").get().count;
      const completedCount = db.prepare("SELECT COUNT(*) as count FROM enquiries WHERE status = 'Completed'").get().count;

      return sendJson(res, 200, {
        success: true,
        stats: {
          total,
          contactCount,
          quoteCount,
          newCount,
          inProgressCount,
          completedCount,
          pipelineEstimate: '₹3,45,000+'
        }
      });
    } catch (err) {
      return sendJson(res, 500, { success: false, error: 'Failed to get stats.' });
    }
  }

  // GET /api/admin/export - CSV Export
  if (req.method === 'GET' && pathname === '/api/admin/export') {
    if (!verifyAuth(req)) {
      return sendJson(res, 401, { success: false, error: 'Unauthorized.' });
    }

    try {
      const rows = db.prepare('SELECT * FROM enquiries ORDER BY id DESC').all();
      let csv = 'ID,Type,Name,Business Name,Email,Mobile,Website Type,Budget,Timeline,Status,Created At,Description,Notes\n';

      for (const r of rows) {
        const escapeCsv = (val) => `"${String(val || '').replace(/"/g, '""')}"`;
        csv += [
          r.id,
          escapeCsv(r.type),
          escapeCsv(r.name),
          escapeCsv(r.business_name),
          escapeCsv(r.email),
          escapeCsv(r.mobile),
          escapeCsv(r.website_type),
          escapeCsv(r.budget),
          escapeCsv(r.timeline),
          escapeCsv(r.status),
          escapeCsv(r.created_at),
          escapeCsv(r.description),
          escapeCsv(r.admin_notes)
        ].join(',') + '\n';
      }

      res.writeHead(200, {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="lakshmi-enquiries-${new Date().toISOString().slice(0, 10)}.csv"`
      });
      return res.end(csv);
    } catch (err) {
      return sendJson(res, 500, { success: false, error: 'Export failed.' });
    }
  }

  // -------------------------------------------------------------
  // STATIC FILE SERVING
  // -------------------------------------------------------------
  let relativePath = pathname;
  if (ROUTE_MAP[pathname]) {
    relativePath = ROUTE_MAP[pathname];
  }

  // Normalize path and prevent directory traversal
  let safePath = path.normalize(path.join(PUBLIC_DIR, relativePath));
  if (!safePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    return res.end('Access Denied');
  }

  // Check if file exists, if not check for .html extension
  if (!fs.existsSync(safePath) || fs.statSync(safePath).isDirectory()) {
    const htmlCandidate = safePath + '.html';
    if (fs.existsSync(htmlCandidate)) {
      safePath = htmlCandidate;
    } else {
      // 404 handler
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <title>404 Page Not Found - Lakshmi Solutions</title>
          <style>
            body { font-family: system-ui, sans-serif; background: #F5F7FA; color: #263247; text-align: center; padding: 100px 20px; }
            h1 { font-size: 3rem; color: #101D35; margin-bottom: 8px; }
            p { font-size: 1.2rem; color: #64748B; margin-bottom: 24px; }
            a { display: inline-block; background: #F59E0B; color: #101D35; font-weight: 700; text-decoration: none; padding: 12px 28px; border-radius: 999px; }
          </style>
        </head>
        <body>
          <h1>404</h1>
          <p>The page you are looking for does not exist.</p>
          <a href="/">Back to Home</a>
        </body>
        </html>
      `);
    }
  }

  // Read file and stream
  const ext = path.extname(safePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(safePath, (err, content) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      return res.end('Internal Server Error');
    }
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(content);
  });
});

server.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`🚀 LAKSHMI SOLUTIONS - Website & Server Live!`);
  console.log(`🌐 URL: http://localhost:${PORT}`);
  console.log(`🔐 Admin Dashboard: http://localhost:${PORT}/admin`);
  console.log(`🔑 Admin Login: admin@lakshmisolutions.com / admin@lakshmi2026`);
  console.log(`💾 Database: SQLite (database.sqlite)`);
  console.log(`====================================================`);
});

