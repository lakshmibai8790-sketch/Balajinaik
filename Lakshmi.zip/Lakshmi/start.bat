@echo off
echo ========================================================
echo   LAKSHMI SOLUTIONS - Starting Agency Web Server
echo   "Your Vision, Our Digital Creation."
echo ========================================================
echo.
node server.js
pause

